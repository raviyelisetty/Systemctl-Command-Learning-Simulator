import { useState, useEffect } from 'react';
import { RotateCcw, Play, BookOpen, X } from 'lucide-react';
import Terminal from './components/Terminal';
import TutorialPanel from './components/TutorialPanel';
import ProgressBar from './components/ProgressBar';
import { SystemctlSimulator } from './utils/systemctl';
import { lessons } from './data/lessons';
import { TerminalLine, Lesson } from './types/systemctl';

function App() {
  const [simulator] = useState(() => new SystemctlSimulator());
  const [history, setHistory] = useState<TerminalLine[]>([]);
  const [tutorialMode, setTutorialMode] = useState(false);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('completedLessons');
    if (saved) {
      setCompletedLessons(new Set(JSON.parse(saved)));
    }
  }, []);

  const handleCommand = (command: string) => {
    const newHistory: TerminalLine[] = [
      ...history,
      {
        type: 'command',
        content: command,
        timestamp: new Date(),
      },
    ];

    const result = simulator.executeCommand(command);

    if (result.output) {
      newHistory.push({
        type: result.type,
        content: result.output,
        timestamp: new Date(),
      });
    }

    setHistory(newHistory);

    if (tutorialMode && currentLesson) {
      checkLessonCompletion(command.trim(), result.success);
    }
  };

  const checkLessonCompletion = (command: string, success: boolean) => {
    if (!currentLesson) return;

    const normalizedCommand = command.toLowerCase().replace(/\s+/g, ' ');
    const expectedCommand = currentLesson.expectedCommand.toLowerCase().replace(/\s+/g, ' ');

    if (normalizedCommand === expectedCommand && success) {
      setFeedback('Excellent! Lesson completed!');
      const newCompleted = new Set(completedLessons);
      newCompleted.add(currentLesson.id);
      setCompletedLessons(newCompleted);
      localStorage.setItem('completedLessons', JSON.stringify([...newCompleted]));

      setTimeout(() => {
        setFeedback(null);
        if (currentLesson.nextLesson) {
          const nextLesson = lessons.find((l) => l.id === currentLesson.nextLesson);
          if (nextLesson) {
            setCurrentLesson(nextLesson);
            setShowHint(false);
          }
        }
      }, 2000);
    } else if (normalizedCommand.startsWith('systemctl') && !success) {
      setFeedback('Command failed. Check your syntax and try again.');
      setTimeout(() => setFeedback(null), 3000);
    } else if (normalizedCommand.startsWith('systemctl') && success) {
      setFeedback('Command executed, but this is not the expected command for this lesson.');
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  const handleReset = () => {
    simulator.reset();
    setHistory([]);
    setFeedback(null);
  };

  const handleStartTutorial = () => {
    setTutorialMode(true);
    setCurrentLesson(lessons[0]);
    setShowHint(false);
    handleReset();
  };

  const handleExitTutorial = () => {
    setTutorialMode(false);
    setCurrentLesson(null);
    setShowHint(false);
    setFeedback(null);
  };

  const handleSelectLesson = (lessonId: string) => {
    const lesson = lessons.find((l) => l.id === lessonId);
    if (lesson) {
      setCurrentLesson(lesson);
      setShowHint(false);
      setFeedback(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">systemctl Learning Simulator</h1>
              <p className="text-sm text-slate-600 mt-1">
                Master Linux service management in a safe environment
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </button>
              {!tutorialMode ? (
                <button
                  onClick={handleStartTutorial}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors shadow-md"
                >
                  <Play className="w-4 h-4" />
                  Start Tutorial
                </button>
              ) : (
                <button
                  onClick={handleExitTutorial}
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors shadow-md"
                >
                  <X className="w-4 h-4" />
                  Exit Tutorial
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {tutorialMode && (
          <div className="mb-6">
            <ProgressBar completed={completedLessons.size} total={lessons.length} />
          </div>
        )}

        {feedback && (
          <div
            className={`mb-6 p-4 rounded-lg border ${
              feedback.includes('Excellent')
                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                : 'bg-amber-50 border-amber-300 text-amber-800'
            }`}
          >
            <p className="font-medium">{feedback}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className={tutorialMode ? 'lg:col-span-2' : 'lg:col-span-3'}>
            <Terminal history={history} onCommand={handleCommand} disabled={false} />
          </div>

          {tutorialMode && (
            <div className="lg:col-span-1">
              <TutorialPanel
                currentLesson={currentLesson}
                completedLessons={completedLessons}
                allLessons={lessons}
                onSelectLesson={handleSelectLesson}
                showHint={showHint}
                onToggleHint={() => setShowHint(!showHint)}
              />
            </div>
          )}
        </div>

        {!tutorialMode && (
          <div className="mt-8 bg-white rounded-lg shadow-md border border-slate-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-blue-600" />
              <h2 className="text-xl font-bold text-slate-800">Quick Start Guide</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h3 className="font-semibold text-slate-700 mb-2">Basic Commands:</h3>
                <ul className="space-y-1 text-slate-600">
                  <li>
                    <code className="bg-slate-100 px-2 py-0.5 rounded">
                      systemctl status &lt;service&gt;
                    </code>{' '}
                    - Check service status
                  </li>
                  <li>
                    <code className="bg-slate-100 px-2 py-0.5 rounded">
                      systemctl start &lt;service&gt;
                    </code>{' '}
                    - Start a service
                  </li>
                  <li>
                    <code className="bg-slate-100 px-2 py-0.5 rounded">
                      systemctl stop &lt;service&gt;
                    </code>{' '}
                    - Stop a service
                  </li>
                  <li>
                    <code className="bg-slate-100 px-2 py-0.5 rounded">
                      systemctl restart &lt;service&gt;
                    </code>{' '}
                    - Restart a service
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-slate-700 mb-2">Available Services:</h3>
                <ul className="space-y-1 text-slate-600">
                  <li>• nginx - Web server</li>
                  <li>• sshd - SSH daemon</li>
                  <li>• docker - Container engine</li>
                  <li>• mysql - Database server</li>
                  <li>• apache2 - HTTP server</li>
                  <li>• postgresql - Database server</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
