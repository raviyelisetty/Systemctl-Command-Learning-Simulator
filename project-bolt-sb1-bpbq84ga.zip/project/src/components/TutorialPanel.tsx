import { BookOpen, CheckCircle2, Circle, ArrowRight } from 'lucide-react';
import { Lesson } from '../types/systemctl';

interface TutorialPanelProps {
  currentLesson: Lesson | null;
  completedLessons: Set<string>;
  allLessons: Lesson[];
  onSelectLesson: (lessonId: string) => void;
  showHint: boolean;
  onToggleHint: () => void;
}

export default function TutorialPanel({
  currentLesson,
  completedLessons,
  allLessons,
  onSelectLesson,
  showHint,
  onToggleHint,
}: TutorialPanelProps) {
  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-xl border border-slate-200 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white border-b border-blue-800">
        <BookOpen className="w-5 h-5" />
        <h2 className="text-lg font-bold">Tutorial Mode</h2>
      </div>

      <div className="flex-1 overflow-y-auto">
        {currentLesson ? (
          <div className="p-4">
            <div className="mb-4">
              <h3 className="text-xl font-bold text-slate-800 mb-2">{currentLesson.title}</h3>
              <p className="text-slate-600 mb-4">{currentLesson.description}</p>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                <h4 className="font-semibold text-blue-900 mb-2">Objective:</h4>
                <p className="text-blue-800">{currentLesson.objective}</p>
              </div>

              <button
                onClick={onToggleHint}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium underline"
              >
                {showHint ? 'Hide Hint' : 'Show Hint'}
              </button>

              {showHint && (
                <div className="mt-3 bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="text-sm text-amber-900">
                    <span className="font-semibold">Hint:</span> {currentLesson.hint}
                  </p>
                </div>
              )}
            </div>

            <div className="border-t border-slate-200 pt-4">
              <h4 className="font-semibold text-slate-700 mb-3">All Lessons</h4>
              <div className="space-y-2">
                {allLessons.map((lesson) => {
                  const isCompleted = completedLessons.has(lesson.id);
                  const isCurrent = currentLesson.id === lesson.id;

                  return (
                    <button
                      key={lesson.id}
                      onClick={() => onSelectLesson(lesson.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors ${
                        isCurrent
                          ? 'bg-blue-100 border border-blue-300'
                          : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-400 flex-shrink-0" />
                      )}
                      <span
                        className={`flex-1 text-sm font-medium ${
                          isCurrent ? 'text-blue-900' : 'text-slate-700'
                        }`}
                      >
                        {lesson.title}
                      </span>
                      {isCurrent && <ArrowRight className="w-4 h-4 text-blue-600" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4">
            <h3 className="text-lg font-semibold text-slate-800 mb-3">Choose a Lesson</h3>
            <div className="space-y-2">
              {allLessons.map((lesson) => {
                const isCompleted = completedLessons.has(lesson.id);

                return (
                  <button
                    key={lesson.id}
                    onClick={() => onSelectLesson(lesson.id)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg text-left bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors"
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400 flex-shrink-0" />
                    )}
                    <span className="flex-1 text-sm font-medium text-slate-700">
                      {lesson.title}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
