export interface Service {
  name: string;
  description: string;
  active: 'active' | 'inactive' | 'failed';
  enabled: boolean;
  masked: boolean;
  pid?: number;
  since?: string;
}

export interface TerminalLine {
  type: 'command' | 'output' | 'error' | 'success';
  content: string;
  timestamp: Date;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  objective: string;
  expectedCommand: string;
  hint: string;
  nextLesson?: string;
}

export interface CommandResult {
  success: boolean;
  output: string;
  type: 'output' | 'error' | 'success';
}
