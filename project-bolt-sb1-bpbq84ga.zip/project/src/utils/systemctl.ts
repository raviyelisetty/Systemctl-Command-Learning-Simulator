import { Service, CommandResult } from '../types/systemctl';

const initialServices: Service[] = [
  {
    name: 'nginx',
    description: 'A high performance web server',
    active: 'inactive',
    enabled: false,
    masked: false,
    since: new Date().toISOString(),
  },
  {
    name: 'sshd',
    description: 'OpenSSH Daemon',
    active: 'active',
    enabled: true,
    masked: false,
    pid: 1234,
    since: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    name: 'docker',
    description: 'Docker Application Container Engine',
    active: 'active',
    enabled: false,
    masked: false,
    pid: 5678,
    since: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    name: 'mysql',
    description: 'MySQL Community Server',
    active: 'inactive',
    enabled: true,
    masked: false,
    since: new Date().toISOString(),
  },
  {
    name: 'apache2',
    description: 'The Apache HTTP Server',
    active: 'failed',
    enabled: false,
    masked: false,
    since: new Date(Date.now() - 300000).toISOString(),
  },
  {
    name: 'postgresql',
    description: 'PostgreSQL RDBMS',
    active: 'inactive',
    enabled: false,
    masked: false,
    since: new Date().toISOString(),
  },
];

export class SystemctlSimulator {
  private services: Map<string, Service>;
  private failedServices: Set<string>;

  constructor() {
    this.services = new Map();
    this.failedServices = new Set();
    initialServices.forEach(service => {
      this.services.set(service.name, { ...service });
      if (service.active === 'failed') {
        this.failedServices.add(service.name);
      }
    });
  }

  executeCommand(command: string): CommandResult {
    const trimmedCommand = command.trim();

    if (!trimmedCommand.startsWith('systemctl')) {
      return {
        success: false,
        output: `bash: ${trimmedCommand.split(' ')[0]}: command not found`,
        type: 'error',
      };
    }

    const parts = trimmedCommand.split(/\s+/);
    const action = parts[1];
    const flags = parts.filter(p => p.startsWith('--'));
    const serviceName = parts.find((p, i) => i > 1 && !p.startsWith('--'));

    switch (action) {
      case 'status':
        return this.status(serviceName!);
      case 'start':
        return this.start(serviceName!);
      case 'stop':
        return this.stop(serviceName!);
      case 'restart':
        return this.restart(serviceName!);
      case 'reload':
        return this.reload(serviceName!);
      case 'reload-or-restart':
        return this.reloadOrRestart(serviceName!);
      case 'try-restart':
        return this.tryRestart(serviceName!);
      case 'enable':
        return this.enable(serviceName!, flags.includes('--now'));
      case 'disable':
        return this.disable(serviceName!, flags.includes('--now'));
      case 'is-active':
        return this.isActive(serviceName!);
      case 'is-enabled':
        return this.isEnabled(serviceName!);
      case 'mask':
        return this.mask(serviceName!);
      case 'unmask':
        return this.unmask(serviceName!);
      case 'kill':
        return this.kill(serviceName!);
      case 'list-units':
        return this.listUnits(parts);
      case 'list-unit-files':
        return this.listUnitFiles();
      case 'list-dependencies':
        return this.listDependencies(serviceName!);
      case 'show':
        return this.show(serviceName!);
      case 'cat':
        return this.cat(serviceName!);
      case 'daemon-reload':
        return this.daemonReload();
      case 'reset-failed':
        return this.resetFailed(serviceName);
      case '--help':
      case 'help':
        return this.help();
      default:
        return {
          success: false,
          output: `Unknown operation '${action}'. Try 'systemctl --help' for more information.`,
          type: 'error',
        };
    }
  }

  private status(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl status <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Unit ${serviceName}.service could not be found.`,
        type: 'error',
      };
    }

    const statusColor = service.active === 'active' ? 'running' : service.active === 'failed' ? 'failed' : 'dead';
    const output = `● ${service.name}.service - ${service.description}
   Loaded: loaded (/lib/systemd/system/${service.name}.service; ${service.enabled ? 'enabled' : 'disabled'})
   Active: ${service.active} (${statusColor})${service.pid ? ` (pid ${service.pid})` : ''}
     Docs: man:${service.name}(8)
  Process: ${service.pid || 'N/A'} ExecStart=/usr/sbin/${service.name} (code=exited, status=0/SUCCESS)
 Main PID: ${service.pid || 'N/A'} (${service.name})
    Since: ${new Date(service.since!).toLocaleString()}
    Tasks: ${service.active === 'active' ? Math.floor(Math.random() * 10) + 1 : 0}
   Memory: ${service.active === 'active' ? `${(Math.random() * 50 + 10).toFixed(1)}M` : '0B'}
   CGroup: /system.slice/${service.name}.service
           ${service.pid ? `└─${service.pid} /usr/sbin/${service.name}` : ''}`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private start(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl start <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to start ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    if (service.active === 'active') {
      return {
        success: true,
        output: '',
        type: 'success',
      };
    }

    service.active = 'active';
    service.pid = Math.floor(Math.random() * 90000) + 10000;
    service.since = new Date().toISOString();
    this.services.set(serviceName, service);

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private stop(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl stop <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to stop ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    service.active = 'inactive';
    service.pid = undefined;
    service.since = new Date().toISOString();
    this.services.set(serviceName, service);

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private restart(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl restart <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to restart ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    service.active = 'active';
    service.pid = Math.floor(Math.random() * 90000) + 10000;
    service.since = new Date().toISOString();
    this.services.set(serviceName, service);

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private reload(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl reload <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to reload ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    if (service.active !== 'active') {
      return {
        success: false,
        output: `Failed to reload ${serviceName}.service: Unit is not active.`,
        type: 'error',
      };
    }

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private reloadOrRestart(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl reload-or-restart <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to reload-or-restart ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    if (service.active === 'active') {
      return this.reload(serviceName);
    } else {
      return this.restart(serviceName);
    }
  }

  private tryRestart(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl try-restart <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to try-restart ${serviceName}.service: Unit ${serviceName}.service not found.`,
        type: 'error',
      };
    }

    if (service.active === 'active') {
      return this.restart(serviceName);
    }

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private enable(serviceName: string, startNow: boolean = false): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl enable <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to enable unit: Unit file ${serviceName}.service does not exist.`,
        type: 'error',
      };
    }

    if (service.masked) {
      return {
        success: false,
        output: `Failed to enable unit: Unit ${serviceName}.service is masked.`,
        type: 'error',
      };
    }

    service.enabled = true;
    this.services.set(serviceName, service);

    let output = `Created symlink /etc/systemd/system/multi-user.target.wants/${serviceName}.service → /lib/systemd/system/${serviceName}.service.`;

    if (startNow && service.active !== 'active') {
      service.active = 'active';
      service.pid = Math.floor(Math.random() * 90000) + 10000;
      service.since = new Date().toISOString();
      this.services.set(serviceName, service);
    }

    return {
      success: true,
      output: service.enabled && !startNow ? output : output,
      type: 'success',
    };
  }

  private disable(serviceName: string, stopNow: boolean = false): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl disable <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to disable unit: Unit file ${serviceName}.service does not exist.`,
        type: 'error',
      };
    }

    service.enabled = false;
    this.services.set(serviceName, service);

    if (stopNow && service.active === 'active') {
      service.active = 'inactive';
      service.pid = undefined;
      service.since = new Date().toISOString();
      this.services.set(serviceName, service);
    }

    return {
      success: true,
      output: `Removed /etc/systemd/system/multi-user.target.wants/${serviceName}.service.`,
      type: 'success',
    };
  }

  private isActive(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl is-active <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: 'unknown',
        type: 'error',
      };
    }

    return {
      success: service.active === 'active',
      output: service.active,
      type: 'output',
    };
  }

  private isEnabled(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl is-enabled <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: 'not-found',
        type: 'error',
      };
    }

    if (service.masked) {
      return {
        success: false,
        output: 'masked',
        type: 'output',
      };
    }

    return {
      success: service.enabled,
      output: service.enabled ? 'enabled' : 'disabled',
      type: 'output',
    };
  }

  private mask(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl mask <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to mask unit: Unit file ${serviceName}.service does not exist.`,
        type: 'error',
      };
    }

    service.masked = true;
    service.enabled = false;
    if (service.active === 'active') {
      service.active = 'inactive';
      service.pid = undefined;
      service.since = new Date().toISOString();
    }
    this.services.set(serviceName, service);

    return {
      success: true,
      output: `Created symlink /etc/systemd/system/${serviceName}.service → /dev/null.`,
      type: 'success',
    };
  }

  private unmask(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl unmask <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to unmask unit: Unit file ${serviceName}.service does not exist.`,
        type: 'error',
      };
    }

    service.masked = false;
    this.services.set(serviceName, service);

    return {
      success: true,
      output: `Removed /etc/systemd/system/${serviceName}.service.`,
      type: 'success',
    };
  }

  private kill(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl kill <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Failed to kill unit ${serviceName}.service: Unit ${serviceName}.service not loaded.`,
        type: 'error',
      };
    }

    if (service.active === 'active') {
      service.active = 'inactive';
      service.pid = undefined;
      service.since = new Date().toISOString();
      this.services.set(serviceName, service);
    }

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private listUnits(parts: string[]): CommandResult {
    const hasTypeService = parts.includes('--type=service');

    if (!hasTypeService) {
      return {
        success: false,
        output: 'Usage: systemctl list-units --type=service',
        type: 'error',
      };
    }

    let output = 'UNIT                    LOAD   ACTIVE   SUB     DESCRIPTION\n';

    this.services.forEach(service => {
      const unit = `${service.name}.service`.padEnd(24);
      const load = 'loaded'.padEnd(7);
      const active = service.active.padEnd(9);
      const sub = (service.active === 'active' ? 'running' : service.active === 'failed' ? 'failed' : 'dead').padEnd(8);
      output += `${unit}${load}${active}${sub}${service.description}\n`;
    });

    output += `\nLOAD   = Reflects whether the unit definition was properly loaded.
ACTIVE = The high-level unit activation state, i.e. generalization of SUB.
SUB    = The low-level unit activation state, values depend on unit type.

${this.services.size} loaded units listed.`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private listUnitFiles(): CommandResult {
    let output = 'UNIT FILE               STATE           VENDOR PRESET\n';

    this.services.forEach(service => {
      const unitFile = `${service.name}.service`.padEnd(24);
      const state = service.masked ? 'masked' : (service.enabled ? 'enabled' : 'disabled');
      output += `${unitFile}${state.padEnd(16)}enabled\n`;
    });

    output += `\n${this.services.size} unit files listed.`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private listDependencies(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl list-dependencies <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Unit ${serviceName}.service could not be found.`,
        type: 'error',
      };
    }

    const output = `${serviceName}.service
● ├─system.slice
● └─basic.target
  ● ├─paths.target
  ● ├─slices.target
  ● ├─sockets.target
  ● └─sysinit.target`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private show(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl show <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `Unit ${serviceName}.service could not be found.`,
        type: 'error',
      };
    }

    const output = `Type=notify
Restart=on-failure
NotifyAccess=main
RestartUSec=100ms
TimeoutStartUSec=1min 30s
TimeoutStopUSec=1min 30s
RuntimeMaxUSec=infinity
WatchdogUSec=0
WatchdogTimestampMonotonic=0
PermissionsStartOnly=no
RootDirectoryStartOnly=no
RemainAfterExit=no
GuessMainPID=yes
MainPID=${service.pid || 0}
ControlPID=0
FileDescriptorStoreMax=0
NFileDescriptorStore=0
StatusErrno=0
Result=success
UID=[not set]
GID=[not set]
NRestarts=0
ExecMainStartTimestamp=${service.since}
ExecMainExitTimestamp=
ExecMainPID=${service.pid || 0}
ExecMainCode=0
ExecMainStatus=0
Description=${service.description}
LoadState=loaded
ActiveState=${service.active}
SubState=${service.active === 'active' ? 'running' : service.active === 'failed' ? 'failed' : 'dead'}
UnitFileState=${service.masked ? 'masked' : (service.enabled ? 'enabled' : 'disabled')}
StateChangeTimestamp=${service.since}`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private cat(serviceName: string): CommandResult {
    if (!serviceName) {
      return {
        success: false,
        output: 'Missing service name. Usage: systemctl cat <service-name>',
        type: 'error',
      };
    }

    const service = this.services.get(serviceName);
    if (!service) {
      return {
        success: false,
        output: `No files found for ${serviceName}.service.`,
        type: 'error',
      };
    }

    const output = `# /lib/systemd/system/${serviceName}.service
[Unit]
Description=${service.description}
After=network.target

[Service]
Type=forking
ExecStart=/usr/sbin/${serviceName}
ExecReload=/bin/kill -s HUP $MAINPID
ExecStop=/bin/kill -s QUIT $MAINPID
PrivateTmp=true

[Install]
WantedBy=multi-user.target`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  private daemonReload(): CommandResult {
    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private resetFailed(serviceName?: string): CommandResult {
    if (serviceName) {
      const service = this.services.get(serviceName);
      if (!service) {
        return {
          success: false,
          output: `Unit ${serviceName}.service could not be found.`,
          type: 'error',
        };
      }

      if (service.active === 'failed') {
        service.active = 'inactive';
        this.services.set(serviceName, service);
        this.failedServices.delete(serviceName);
      }
    } else {
      this.services.forEach((service, name) => {
        if (service.active === 'failed') {
          service.active = 'inactive';
          this.services.set(name, service);
        }
      });
      this.failedServices.clear();
    }

    return {
      success: true,
      output: '',
      type: 'success',
    };
  }

  private help(): CommandResult {
    const output = `systemctl [OPTIONS...] COMMAND ...

Query or send control commands to the systemd manager.

Service Management:
  status [NAME...]              Show runtime status of one or more units
  start NAME...                 Start (activate) one or more units
  stop NAME...                  Stop (deactivate) one or more units
  restart NAME...               Restart one or more units
  reload NAME...                Reload one or more units
  reload-or-restart NAME...     Reload or restart units
  try-restart NAME...           Restart if active
  kill NAME...                  Send signal to processes of a unit
  is-active NAME...             Check if units are active
  is-enabled NAME...            Check if unit files are enabled

Enable/Disable:
  enable NAME...                Enable one or more unit files
  enable --now NAME...          Enable and start one or more units
  disable NAME...               Disable one or more unit files
  disable --now NAME...         Disable and stop one or more units
  mask NAME...                  Mask one or more units
  unmask NAME...                Unmask one or more units

List & Show:
  list-units [PATTERN...]       List units currently in memory
  list-unit-files [PATTERN...]  List installed unit files
  list-dependencies [NAME]      Show dependencies of a unit
  show [NAME...]                Show properties of units
  cat NAME...                   Show backing files of units

System:
  daemon-reload                 Reload systemd manager configuration
  reset-failed [NAME...]        Reset failed state for all or specific units

Options:
  --type=TYPE                   List units of a particular type
  --now                         Start/stop unit when enabling/disabling
  --help                        Show this help`;

    return {
      success: true,
      output,
      type: 'output',
    };
  }

  reset(): void {
    this.services.clear();
    this.failedServices.clear();
    initialServices.forEach(service => {
      this.services.set(service.name, { ...service });
      if (service.active === 'failed') {
        this.failedServices.add(service.name);
      }
    });
  }
}
